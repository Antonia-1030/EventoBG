package com.myapp.data;

public enum Role {
    USER, ADMIN;
}
