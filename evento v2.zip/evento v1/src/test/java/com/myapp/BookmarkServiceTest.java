package com.myapp;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;
import java.util.Optional;

import com.myapp.models.Bookmark;
import com.myapp.models.Event;
import com.myapp.repo.BookmarkRepo;
import com.myapp.repo.EventRepo;
import com.myapp.services.BookmarkService;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;

public class BookmarkServiceTest {
    @Mock
    private BookmarkRepo repository;

    @Mock
    private EventRepo eventRepo;

    @InjectMocks
    private BookmarkService service;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testGet() {
        Bookmark bookmark = new Bookmark();
        when(repository.findById(anyLong())).thenReturn(Optional.of(bookmark));

        Optional<Bookmark> result = service.get(1L);
        assertTrue(result.isPresent());
        assertEquals(bookmark, result.get());
    }

    @Test
    public void testGetEvent() {
        Event event = new Event();
        when(eventRepo.findById(anyLong())).thenReturn(Optional.of(event));

        Optional<Event> result = service.getEvent(1L);
        assertTrue(result.isPresent());
        assertEquals(event, result.get());
    }

    @Test
    public void testUpdate() {
        Bookmark bookmark = new Bookmark();
        when(repository.save(any(Bookmark.class))).thenReturn(bookmark);

        Bookmark result = service.update(bookmark);
        assertNotNull(result);
        assertEquals(bookmark, result);
    }

    @Test
    public void testDelete() {
        service.delete(1L);
        verify(repository).deleteById(1L);
    }

    @Test
    public void testList() {
        Pageable pageable = PageRequest.of(0, 10);
        Page<Bookmark> page = new PageImpl<>(List.of(new Bookmark()));
        when(repository.findAll(any(Pageable.class))).thenReturn(page);

        Page<Bookmark> result = service.list(pageable);
        assertNotNull(result);
        assertEquals(1, result.getTotalElements());
    }

    @Test
    public void testListWithFilter() {
        Pageable pageable = PageRequest.of(0, 10);
        Specification<Bookmark> specification = (root, query, criteriaBuilder) -> criteriaBuilder.conjunction();
        Page<Bookmark> page = new PageImpl<>(List.of(new Bookmark()));
        when(repository.findAll(any(Specification.class), any(Pageable.class))).thenReturn(page);

        Page<Bookmark> result = service.list(pageable, specification);
        assertNotNull(result);
        assertEquals(1, result.getTotalElements());
    }

    @Test
    public void testCount() {
        when(repository.count()).thenReturn(5L);

        int result = service.count();
        assertEquals(5, result);
    }
}
