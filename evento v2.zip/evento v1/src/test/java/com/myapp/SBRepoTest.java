package com.myapp;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;


import com.myapp.models.Event;
import com.myapp.repo.EventRepo;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

public class SBRepoTest {
    @Mock
    private EventRepo eventRepo;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testSave() {
        Event book = new Event();
        book.setId(1L);
        book.setName("Test Book");

        when(eventRepo.save(book)).thenReturn(book);

        Event savedBook = eventRepo.save(book);

        assertNotNull(savedBook);
        assertEquals(book.getId(), savedBook.getId());
        assertEquals(book.getName(), savedBook.getName());
    }

    @Test
    public void testFindById() {
        Event book = new Event();
        book.setId(1L);
        book.setName("Test Book");

        when(eventRepo.findById(1L)).thenReturn(Optional.of(book));

        Optional<Event> foundBook = eventRepo.findById(1L);

        assertTrue(foundBook.isPresent());
        assertEquals(book.getId(), foundBook.get().getId());
        assertEquals(book.getName(), foundBook.get().getName());
    }

    @Test
    public void testFindAll() {
        Event book1 = new Event();
        book1.setId(1L);
        book1.setName("Test Book 1");

        Event book2 = new Event();
        book2.setId(2L);
        book2.setName("Test Book 2");

        List<Event> books = Arrays.asList(book1, book2);

        when(eventRepo.findAll()).thenReturn(books);

        List<Event> foundBooks = eventRepo.findAll();

        assertNotNull(foundBooks);
        assertEquals(2, foundBooks.size());
        assertEquals(book1.getName(), foundBooks.get(0).getName());
        assertEquals(book2.getName(), foundBooks.get(1).getName());
    }

    @Test
    public void testDeleteById() {
        Event book = new Event();
        book.setId(1L);
        book.setName("Test Book");

        doNothing().when(eventRepo).deleteById(1L);

        eventRepo.deleteById(1L);

        verify(eventRepo, times(1)).deleteById(1L);
    }
}
