package com.myapp;

import com.myapp.models.Event;
import com.myapp.repo.EventRepo;
import com.myapp.services.EventService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;

import java.util.Collections;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

public class SBServiceTest {
    @Mock
    private EventRepo eventRepo;

    @InjectMocks
    private EventService eventService;

    private Event event;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        event = new Event();
        event.setId(1L);
        event.setName("Test Book");
        event.setAuthor("Test Author");
    }

    @Test
    public void whenGetSampleBook_thenReturnSampleBook() {
        when(eventRepo.findById(1L)).thenReturn(Optional.of(event));

        Optional<Event> found = eventService.get(1L);

        assertThat(found).isPresent();
        assertThat(found.get().getName()).isEqualTo(event.getName());
    }

    @Test
    public void whenUpdateSampleBook_thenReturnUpdatedSampleBook() {
        when(eventRepo.save(any(Event.class))).thenReturn(event);

        Event updated = eventService.update(event);

        assertThat(updated).isNotNull();
        assertThat(updated.getName()).isEqualTo(event.getName());
    }

    @Test
    public void whenDeleteSampleBook_thenVerifyDeletion() {
        doNothing().when(eventRepo).deleteById(1L);

        eventService.delete(1L);

        verify(eventRepo, times(1)).deleteById(1L);
    }

    @Test
    public void whenListSampleBooks_thenReturnSampleBookPage() {
        Pageable pageable = PageRequest.of(0, 10);
        Page<Event> page = new PageImpl<>(Collections.singletonList(event));
        when(eventRepo.findAll(pageable)).thenReturn(page);

        Page<Event> result = eventService.list(pageable);

        assertThat(result).isNotNull();
        assertThat(result.getContent()).hasSize(1);
        assertThat(result.getContent().get(0).getName()).isEqualTo(event.getName());
    }

    @Test
    public void whenListSampleBooksWithSpecification_thenReturnSampleBookPage() {
        Pageable pageable = PageRequest.of(0, 10);
        Specification<Event> specification = mock(Specification.class);
        Page<Event> page = new PageImpl<>(Collections.singletonList(event));
        when(eventRepo.findAll(any(Specification.class), eq(pageable))).thenReturn(page);

        Page<Event> result = eventService.list(pageable, specification);

        assertThat(result).isNotNull();
        assertThat(result.getContent()).hasSize(1);
        assertThat(result.getContent().get(0).getName()).isEqualTo(event.getName());
    }

    @Test
    public void whenCountSampleBooks_thenReturnSampleBookCount() {
        when(eventRepo.count()).thenReturn(1L);

        int count = eventService.count();

        assertThat(count).isEqualTo(1);
    }
}
