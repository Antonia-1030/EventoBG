package com.myapp;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;
import java.util.Optional;

import com.myapp.models.Category;
import com.myapp.repo.CategoryRepo;
import com.myapp.services.CategoryService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;

@ExtendWith(MockitoExtension.class)
public class CategoryServiceTest {
    @Mock
    private CategoryRepo repository;

    @InjectMocks
    private CategoryService service;

    private Category category;

    @BeforeEach
    public void setUp() {
        category = new Category();
        category.setId(1L);
        category.setName("Test Category");
    }

    @Test
    public void testGet() {
        when(repository.findById(anyLong())).thenReturn(Optional.of(category));

        Optional<Category> result = service.get(1L);
        assertTrue(result.isPresent());
        assertEquals(category, result.get());
    }

    @Test
    public void testUpdate() {
        when(repository.save(any(Category.class))).thenReturn(category);

        Category result = service.update(category);
        assertNotNull(result);
        assertEquals(category, result);
    }

    @Test
    public void testDelete() {
        service.delete(1L);
        verify(repository).deleteById(1L);
    }

    @Test
    public void testList() {
        Pageable pageable = PageRequest.of(0, 10);
        Page<Category> page = new PageImpl<>(List.of(category));
        when(repository.findAll(any(Pageable.class))).thenReturn(page);

        Page<Category> result = service.list(pageable);
        assertNotNull(result);
        assertEquals(1, result.getTotalElements());
    }

    @Test
    public void testListWithFilter() {
        Pageable pageable = PageRequest.of(0, 10);
        Specification<Category> specification = (root, query, criteriaBuilder) -> criteriaBuilder.conjunction();
        Page<Category> page = new PageImpl<>(List.of(category));
        when(repository.findAll(any(Specification.class), any(Pageable.class))).thenReturn(page);

        Page<Category> result = service.list(pageable, specification);
        assertNotNull(result);
        assertEquals(1, result.getTotalElements());
    }

    @Test
    public void testCount() {
        when(repository.count()).thenReturn(5L);

        int result = service.count();
        assertEquals(5, result);
    }
}
