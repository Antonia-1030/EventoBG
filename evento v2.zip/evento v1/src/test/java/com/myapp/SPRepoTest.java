package com.myapp;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import com.myapp.models.SamplePerson;
import com.myapp.repo.SamplePersonRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

public class SPRepoTest {
    @Mock
    private SamplePersonRepository samplePersonRepository;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testSave() {
        SamplePerson person = new SamplePerson();
        person.setId(1L);
        person.setFirstName("John Doe");

        when(samplePersonRepository.save(person)).thenReturn(person);

        SamplePerson savedPerson = samplePersonRepository.save(person);

        assertNotNull(savedPerson);
        assertEquals(person.getId(), savedPerson.getId());
        assertEquals(person.getFirstName(), savedPerson.getFirstName());
    }

    @Test
    public void testFindById() {
        SamplePerson person = new SamplePerson();
        person.setId(1L);
        person.setFirstName("John");

        when(samplePersonRepository.findById(1L)).thenReturn(Optional.of(person));

        Optional<SamplePerson> foundPerson = samplePersonRepository.findById(1L);

        assertTrue(foundPerson.isPresent());
        assertEquals(person.getId(), foundPerson.get().getId());
        assertEquals(person.getFirstName(), foundPerson.get().getFirstName());
    }

    @Test
    public void testFindAll() {
        SamplePerson person1 = new SamplePerson();
        person1.setId(1L);
        person1.setFirstName("Penny");

        SamplePerson person2 = new SamplePerson();
        person2.setId(2L);
        person2.setFirstName("Bob");

        List<SamplePerson> persons = Arrays.asList(person1, person2);

        when(samplePersonRepository.findAll()).thenReturn(persons);

        List<SamplePerson> foundPersons = samplePersonRepository.findAll();

        assertNotNull(foundPersons);
        assertEquals(2, foundPersons.size());
        assertEquals(person1.getFirstName(), foundPersons.get(0).getFirstName());
        assertEquals(person2.getFirstName(), foundPersons.get(1).getFirstName());
    }

    @Test
    public void testDeleteById() {
        SamplePerson person = new SamplePerson();
        person.setId(1L);
        person.setFirstName("Nate");

        doNothing().when(samplePersonRepository).deleteById(1L);

        samplePersonRepository.deleteById(1L);

        verify(samplePersonRepository, times(1)).deleteById(1L);
    }
}
