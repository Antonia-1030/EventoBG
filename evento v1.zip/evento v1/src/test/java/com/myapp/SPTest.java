package com.myapp;

import com.myapp.models.SamplePerson;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;

import static org.assertj.core.api.Assertions.assertThat;

public class SPTest {
    @Test
    public void testGetSetFirstName() {
        SamplePerson samplePerson = new SamplePerson();
        String firstName = "Ben";
        samplePerson.setFirstName(firstName);
        assertThat(samplePerson.getFirstName()).isEqualTo(firstName);
    }

    @Test
    public void testGetSetPassword() {
        SamplePerson samplePerson = new SamplePerson();
        String password = "Asfef2324";
        samplePerson.setPassword(password);
        assertThat(samplePerson.getPassword()).isEqualTo(password);
    }

    @Test
    public void testGetSetEmail() {
        SamplePerson samplePerson = new SamplePerson();
        String email = "ben.eas@example.com";
        samplePerson.setEmail(email);
        assertThat(samplePerson.getEmail()).isEqualTo(email);
    }

    @Test
    public void testGetSetPhone() {
        SamplePerson samplePerson = new SamplePerson();
        String phone = "123-433-4431";
        samplePerson.setPhone(phone);
        assertThat(samplePerson.getPhone()).isEqualTo(phone);
    }

    @Test
    public void testGetSetDateOfBirth() {
        SamplePerson samplePerson = new SamplePerson();
        LocalDate dateOfBirth = LocalDate.of(1990, 1, 1);
        samplePerson.setDateOfBirth(dateOfBirth);
        assertThat(samplePerson.getDateOfBirth()).isEqualTo(dateOfBirth);
    }

    @Test
    public void testGetSetRole() {
        SamplePerson samplePerson = new SamplePerson();
        String role = "USER";
        samplePerson.setRole(role);
        assertThat(samplePerson.getRole()).isEqualTo(role);
    }
}
