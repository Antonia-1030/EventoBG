package com.myapp;

import com.myapp.models.User;
import com.myapp.repo.UserRepository;
import com.myapp.services.UserService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;

import java.util.Collections;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

public class UserServiceTest {
    @Mock
    private UserRepository userRepository;

    @InjectMocks
    private UserService userService;

    private User user;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        user = new User();
        user.setId(1L);
        user.setUsername("testUser");
        user.setName("Test Name");
        user.setHashedPassword("hashedPassword123");
    }

    @Test
    public void whenGetUser_thenReturnUser() {
        when(userRepository.findById(1L)).thenReturn(Optional.of(user));

        Optional<User> found = userService.get(1L);

        assertThat(found).isPresent();
        assertThat(found.get().getUsername()).isEqualTo(user.getUsername());
    }

    @Test
    public void whenUpdateUser_thenReturnUpdatedUser() {
        when(userRepository.save(any(User.class))).thenReturn(user);

        User updated = userService.update(user);

        assertThat(updated).isNotNull();
        assertThat(updated.getUsername()).isEqualTo(user.getUsername());
    }

    @Test
    public void whenDeleteUser_thenVerifyDeletion() {
        doNothing().when(userRepository).deleteById(1L);

        userService.delete(1L);

        verify(userRepository, times(1)).deleteById(1L);
    }

    @Test
    public void whenListUsers_thenReturnUserPage() {
        Pageable pageable = PageRequest.of(0, 10);
        Page<User> page = new PageImpl<>(Collections.singletonList(user));
        when(userRepository.findAll(pageable)).thenReturn(page);

        Page<User> result = userService.list(pageable);

        assertThat(result).isNotNull();
        assertThat(result.getContent()).hasSize(1);
        assertThat(result.getContent().get(0).getUsername()).isEqualTo(user.getUsername());
    }

    @Test
    public void whenListUsersWithSpecification_thenReturnUserPage() {
        Pageable pageable = PageRequest.of(0, 10);
        Specification<User> specification = mock(Specification.class);
        Page<User> page = new PageImpl<>(Collections.singletonList(user));
        when(userRepository.findAll(any(Specification.class), eq(pageable))).thenReturn(page);

        Page<User> result = userService.list(pageable, specification);

        assertThat(result).isNotNull();
        assertThat(result.getContent()).hasSize(1);
        assertThat(result.getContent().get(0).getUsername()).isEqualTo(user.getUsername());
    }

    @Test
    public void whenCountUsers_thenReturnUserCount() {
        when(userRepository.count()).thenReturn(1L);

        int count = userService.count();

        assertThat(count).isEqualTo(1);
    }
}
