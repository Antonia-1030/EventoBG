package com.myapp;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import com.myapp.models.Bookmark;
import com.myapp.repo.BookmarkRepo;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.Arrays;
import java.util.List;

public class BookmarkRepoTest {
    @Mock
    private BookmarkRepo bookmarkRepo;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testFindById() {
        Bookmark bookmark = new Bookmark();
        bookmark.setId(1L);
        bookmark.setName("Test Bookmark");

        List<Bookmark> mockResult = List.of(bookmark);

        when(bookmarkRepo.findById(bookmark)).thenReturn(mockResult);

        List<Bookmark> bookmarks = bookmarkRepo.findById(bookmark);

        assertNotNull(bookmarks);
        assertEquals(1, bookmarks.size());
        assertEquals(bookmark.getId(), bookmarks.get(0).getId());
        assertEquals(bookmark.getName(), bookmarks.get(0).getName());
    }
}
