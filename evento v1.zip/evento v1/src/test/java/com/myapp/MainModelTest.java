package com.myapp;

import com.myapp.data.MainModel;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;

import static org.assertj.core.api.Assertions.assertThat;

public class MainModelTest {
    private MainModel mainModel;

    @BeforeEach
    public void setUp() {
        mainModel = new MainModel();
    }

    @Test
    public void testGetAndSetId() {
        Long id = 1L;
        mainModel.setId(id);
        assertThat(mainModel.getId()).isEqualTo(id);
    }

    @Test
    public void testGetAndSetUpdatedAt() {
        LocalDateTime updatedAt = LocalDateTime.now();
        mainModel.setUpdatedAt(updatedAt);
        assertThat(mainModel.getUpdatedAt()).isEqualTo(updatedAt);
    }

    @Test
    public void testGetAndSetCreatedAt() {
        LocalDateTime createdAt = LocalDateTime.now();
        mainModel.setCreatedAt(createdAt);
        assertThat(mainModel.getCreatedAt()).isEqualTo(createdAt);
    }
}
