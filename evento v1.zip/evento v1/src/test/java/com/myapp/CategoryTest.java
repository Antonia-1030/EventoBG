package com.myapp;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.myapp.models.Category;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;


public class CategoryTest {
    private Category category1;
    private Category category2;

    @BeforeEach
    public void setUp() {
        category1 = new Category();
        category2 = new Category();
    }

    @Test
    public void testGetAndSetName() {
        String name = "Test Category";
        category1.setName(name);
        assertEquals(name, category1.getName());
    }

    @Test
    public void testGetAndSetId() {
        Long id = 1L;
        category1.setId(id);
        assertEquals(id, category1.getId());
    }

    @Test
    public void testGetVersion() {
        int version = category1.getVersion();
        assertEquals(0, version); // Assuming the default version is 0
    }

    @Test
    public void testEqualsAndHashCode() {
        Long id = 1L;
        category1.setId(id);
        category2.setId(id);

        assertEquals(category1, category2);
        assertEquals(category1.hashCode(), category2.hashCode());

        category2.setId(2L);
        assertNotEquals(category1, category2);
        assertNotEquals(category1.hashCode(), category2.hashCode());
    }

    @Test
    public void testEqualsWithDifferentTypes() {
        assertNotEquals("not a category", category1);
    }

    @Test
    public void testEqualsWithNull() {
        assertNotEquals(null, category1);
    }

    @Test
    public void testEqualsWithSelf() {
        assertEquals(category1, category1);
    }

    @Test
    public void testHashCodeWithNullId() {
        assertEquals(System.identityHashCode(category1), category1.hashCode());
    }
}
