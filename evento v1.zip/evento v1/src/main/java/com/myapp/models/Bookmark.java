package com.myapp.models;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;
import java.util.List;

@Getter
@Setter
@Entity
@Table(name = "Bookmark")
public class Bookmark extends AbstractEntity{
    @Lob
    @Column(length = 1000000)
    private byte[] image;
    @Column(nullable = false,length = 256)
    private String name;
    @OneToMany(cascade = CascadeType.ALL)
    private List<Event> event;
    private LocalDate startDate;
    private LocalDate endDate;

    public List<Event> getEvent() {
        return event;
    }
    public void setEvent(List<Event> event) {
        this.event = event;
    }
}
