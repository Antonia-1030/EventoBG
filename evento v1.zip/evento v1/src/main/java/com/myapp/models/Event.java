package com.myapp.models;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;
import java.util.List;
import java.util.Set;

@Getter
@Setter
@Entity
public class Event extends AbstractEntity {

    @Lob
    @Column(length = 1000000)
    private byte[] image;
    private String name;
    @OneToMany(cascade = CascadeType.ALL,fetch = FetchType.EAGER)
    private Set<Category> category;
    private String author;
    private String location;
    private LocalDate startDate;
    private LocalDate endDate;
    private Double price;

    public byte[] getImage() {
        return image;
    }
    public void setImage(byte[] image) {
        this.image = image;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getAuthor() {
        return author;
    }
    public void setAuthor(String author) {
        this.author = author;
    }
    public String getLocation() {
        return location;
    }
    public void setLocation(String location){this.location=location;}
    public LocalDate getStartDate() {
        return startDate;
    }
    public void setStartDate(LocalDate startDate) {
        this.startDate = startDate;
    }
    public LocalDate getEndDate() {
        return endDate;
    }
    public void setEndDate(LocalDate endDate) {
        this.endDate = endDate;
    }
    public Double getPrice(){return price;}
    public void setPrice(Double price){this.price=price;}

    public Set<Category> getCategory() {
        return category;
    }
    public void setCategory(Set<Category> category) {
        this.category = category;
    }

}
