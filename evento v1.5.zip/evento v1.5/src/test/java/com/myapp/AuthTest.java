package com.myapp;

import com.myapp.repo.UserRepository;
import com.myapp.security.AuthenticatedUser;
import com.vaadin.flow.spring.security.AuthenticationContext;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.User;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

public class AuthTest {
    @Mock
    private UserRepository userRepository;

    @Mock
    private AuthenticationContext authenticationContext;

    @InjectMocks
    private AuthenticatedUser authenticatedUser;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    @Transactional
    public void whenUserIsAuthenticated_thenReturnUser() {
        // Mock authenticated user details
        UserDetails userDetails = mock(UserDetails.class);
        when(userDetails.getUsername()).thenReturn("testUser");
        when(authenticationContext.getAuthenticatedUser(UserDetails.class)).thenReturn(Optional.of(userDetails));

    }

    @Test
    @Transactional
    public void whenUserIsNotAuthenticated_thenReturnEmpty() {
        // Mock no authenticated user
        when(authenticationContext.getAuthenticatedUser(UserDetails.class)).thenReturn(Optional.empty());

        // Call the method under test
        Optional<com.myapp.models.User> result = authenticatedUser.get();

        // Verify interactions and assertions
        verify(userRepository, never()).findByUsername(anyString());
        assertThat(result).isNotPresent();
    }

    @Test
    public void whenLogout_thenCallAuthenticationContextLogout() {
        // Call the method under test
        authenticatedUser.logout();

        // Verify interactions
        verify(authenticationContext).logout();
    }
}
