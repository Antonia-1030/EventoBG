package com.myapp;

import com.myapp.models.Category;
import com.myapp.models.Event;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static org.assertj.core.api.Assertions.assertThat;

public class SBTest {
    @Test
    public void testGetSetImage() {
        Event event = new Event();
        byte[] image = new byte[]{1, 2, 3};
        event.setImage(image);
        assertThat(event.getImage()).isEqualTo(image);
    }

    @Test
    public void testGetSetName() {
        Event event = new Event();
        String name = "Bloodborn";
        event.setName(name);
        assertThat(event.getName()).isEqualTo(name);
    }

    @Test
    public void testGetSetAuthor() {
        Event event = new Event();
        String author = "Might Guy";
        event.setAuthor(author);
        assertThat(event.getAuthor()).isEqualTo(author);
    }

    @Test
    public void testGetSetPublicationDate() {
        Event event = new Event();
        LocalDate publicationDate = LocalDate.of(2022, 3, 5);
        event.setStartDate(publicationDate);
        assertThat(event.getStartDate()).isEqualTo(publicationDate);
    }

    @Test
    public void testGetSetPrice() {
        Event event = new Event();
        double price = 19.99;
        event.setPrice(price);
        assertThat(event.getPrice()).isEqualTo(price);
    }

    @Test
    public void testGetSetCategory() {
        Event event = new Event();
        Category category1 = new Category();
        Category category2 = new Category();
        Set<Category> categories = new HashSet<>();
        categories.add(category1);
        categories.add(category2);
        event.setCategory(categories);
        assertThat(event.getCategory()).isEqualTo(categories);
    }
}
