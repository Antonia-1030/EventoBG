package com.myapp;

import com.myapp.models.SamplePerson;
import com.myapp.repo.SamplePersonRepository;
import com.myapp.services.SamplePersonService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;

import java.util.Collections;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

public class SPServiceTest {
    @Mock
    private SamplePersonRepository samplePersonRepository;

    @InjectMocks
    private SamplePersonService samplePersonService;

    private SamplePerson samplePerson;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        samplePerson = new SamplePerson();
        samplePerson.setId(1L);
        samplePerson.setFirstName("John Doe");
    }

    @Test
    public void whenGetSamplePerson_thenReturnSamplePerson() {
        when(samplePersonRepository.findById(1L)).thenReturn(Optional.of(samplePerson));

        Optional<SamplePerson> found = samplePersonService.get(1L);

        assertThat(found).isPresent();
        assertThat(found.get().getFirstName()).isEqualTo(samplePerson.getFirstName());
    }

    @Test
    public void whenUpdateSamplePerson_thenReturnUpdatedSamplePerson() {
        when(samplePersonRepository.save(any(SamplePerson.class))).thenReturn(samplePerson);

        SamplePerson updated = samplePersonService.update(samplePerson);

        assertThat(updated).isNotNull();
        assertThat(updated.getFirstName()).isEqualTo(samplePerson.getFirstName());
    }

    @Test
    public void whenDeleteSamplePerson_thenVerifyDeletion() {
        doNothing().when(samplePersonRepository).deleteById(1L);

        samplePersonService.delete(1L);

        verify(samplePersonRepository, times(1)).deleteById(1L);
    }

    @Test
    public void whenListSamplePersons_thenReturnSamplePersonPage() {
        Pageable pageable = Pageable.unpaged();
        Page<SamplePerson> page = new PageImpl<>(Collections.singletonList(samplePerson));
        when(samplePersonRepository.findAll(pageable)).thenReturn(page);

        Page<SamplePerson> result = samplePersonService.list(pageable);

        assertThat(result).isNotNull();
        assertThat(result.getContent()).hasSize(1);
        assertThat(result.getContent().get(0).getFirstName()).isEqualTo(samplePerson.getFirstName());
    }

    @Test
    public void whenListSamplePersonsWithSpecification_thenReturnSamplePersonPage() {
        Pageable pageable = Pageable.unpaged();
        Specification<SamplePerson> specification = mock(Specification.class);
        Page<SamplePerson> page = new PageImpl<>(Collections.singletonList(samplePerson));
        when(samplePersonRepository.findAll(any(Specification.class), eq(pageable))).thenReturn(page);

        Page<SamplePerson> result = samplePersonService.list(pageable, specification);

        assertThat(result).isNotNull();
        assertThat(result.getContent()).hasSize(1);
        assertThat(result.getContent().get(0).getFirstName()).isEqualTo(samplePerson.getFirstName());
    }

    @Test
    public void whenCountSamplePersons_thenReturnSamplePersonCount() {
        when(samplePersonRepository.count()).thenReturn(1L);

        int count = samplePersonService.count();

        assertThat(count).isEqualTo(1);
    }
}
