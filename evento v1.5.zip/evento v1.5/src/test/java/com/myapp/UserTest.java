package com.myapp;

import com.myapp.data.Role;
import com.myapp.models.User;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.HashSet;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;

public class UserTest {
    private User user;

    @BeforeEach
    public void setUp() {
        user = new User();
    }

    @Test
    public void testUsername() {
        user.setUsername("testUser");
        assertEquals("testUser", user.getUsername());
    }

    @Test
    public void testName() {
        user.setName("Test Name");
        assertEquals("Test Name", user.getName());
    }

    @Test
    public void testHashedPassword() {
        user.setHashedPassword("hashedPassword123");
        assertEquals("hashedPassword123", user.getHashedPassword());
    }

    @Test
    public void testProfilePicture() {
        byte[] profilePicture = new byte[]{1, 2, 3};
        user.setProfilePicture(profilePicture);
        assertArrayEquals(profilePicture, user.getProfilePicture());
    }
}
