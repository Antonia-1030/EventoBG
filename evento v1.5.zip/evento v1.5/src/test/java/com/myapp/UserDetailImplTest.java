package com.myapp;

import com.myapp.data.Role;
import com.myapp.models.User;
import com.myapp.repo.UserRepository;
import com.myapp.security.UserDetailsServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

public class UserDetailImplTest {
    @Mock
    private UserRepository userRepository;

    @InjectMocks
    private UserDetailsServiceImpl userDetailsService;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void whenValidUsername_thenLoadUserByUsername() {
        String username = "testUser";
        User user = new User();
        user.setUsername(username);
        user.setHashedPassword("hashedPassword123");

        when(userRepository.findByUsername(username)).thenReturn(user);
    }

    @Test
    public void whenInvalidUsername_thenThrowUsernameNotFoundException() {
        String username = "invalidUser";
        when(userRepository.findByUsername(username)).thenReturn(null);

        assertThrows(UsernameNotFoundException.class, () -> {
            userDetailsService.loadUserByUsername(username);
        });
    }
}
