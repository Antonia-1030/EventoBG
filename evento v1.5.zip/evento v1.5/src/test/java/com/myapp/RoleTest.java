package com.myapp;

import com.myapp.data.Role;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class RoleTest {
    @Test
    public void testRoleValues() {
        Role[] roles = Role.values();
        assertEquals(2, roles.length);
        assertTrue(containsRole(roles, Role.USER));
        assertTrue(containsRole(roles, Role.ADMIN));
    }

    @Test
    public void testRoleValueOf() {
        assertEquals(Role.USER, Role.valueOf("USER"));
        assertEquals(Role.ADMIN, Role.valueOf("ADMIN"));
    }

    private boolean containsRole(Role[] roles, Role role) {
        for (Role r : roles) {
            if (r == role) {
                return true;
            }
        }
        return false;
    }
}
