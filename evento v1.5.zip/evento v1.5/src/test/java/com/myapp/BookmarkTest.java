package com.myapp;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.myapp.models.Bookmark;
import com.myapp.models.Event;
import org.junit.Before;
import org.junit.Test;

public class BookmarkTest {
    private Bookmark bookmark;

    @Before
    public void setUp() {
        bookmark = new Bookmark();
    }


    @Test
    public void testImage() {
        byte[] image = new byte[]{1, 2, 3, 4, 5};
        bookmark.setImage(image);
        assertEquals(image, bookmark.getImage());
    }

    @Test
    public void testStartDate() {
        LocalDate startDate = LocalDate.of(2023, 6, 1);
        bookmark.setStartDate(startDate);
        assertEquals(startDate, bookmark.getStartDate());
    }

    @Test
    public void testEndDate() {
        LocalDate endDate = LocalDate.of(2023, 6, 30);
        bookmark.setEndDate(endDate);
        assertEquals(endDate, bookmark.getEndDate());
    }
}
