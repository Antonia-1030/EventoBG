package com.myapp.services;

import com.myapp.data.BaseService;
import com.myapp.models.AppUser;
import com.myapp.repo.AppUserRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;

@Service
public class AppUserService extends BaseService<AppUser> {
    @Autowired
    AppUserRepo userRepo;

    @Override
    protected JpaRepository<AppUser, Long> getRepo() {
        return userRepo;
    }
}
