@NonNullApi
package com.myapp.data;

import org.springframework.lang.NonNullApi;
