package com.myapp.models;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;
import java.util.Set;

@Getter
@Setter
@Entity
@Table(name = "Bookmark")
public class Bookmark extends AbstractEntity{
    @Lob
    @Column(length = 1000000)
    private byte[] image;
    @ManyToOne(cascade = CascadeType.ALL,fetch = FetchType.EAGER)
    @JoinColumn(name = "event_id", nullable = false)
    private Event event;
    private LocalDate startDate;
    private LocalDate endDate;
}
