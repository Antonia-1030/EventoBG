import { ComponentMetadata } from '../model';
export declare function createGenericMetadata(tagName: string): ComponentMetadata;
